import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Project/*Main class to start the whole project*/ {

	public static void main(String[] args) throws FileNotFoundException {
		Project401 form1=new Project401();
		form1.frame.setVisible(true);
        
		
		
	}
}

	