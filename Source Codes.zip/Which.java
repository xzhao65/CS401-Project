/*To determine the limit condition set by user */
   public enum Which{ PROVIDER,NAME, PRICE, DISCOUNTRATE,EXPIRATIONPERIOD,USED,FINALPRICE };
